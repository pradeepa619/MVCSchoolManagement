﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SchoolManagementMVC.Migrations
{
    public partial class SchoolDBContet : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "students",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FirstMidName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Gender = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Age = table.Column<int>(type: "int", nullable: false),
                    Grade = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EnrollmentDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_students", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Teachers",
                columns: table => new
                {
                    TeacherID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HireDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FirstMidName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Teachers", x => x.TeacherID);
                });

            migrationBuilder.CreateTable(
                name: "Department",
                columns: table => new
                {
                    DepartmentID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Budget = table.Column<decimal>(type: "money", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TeacherID = table.Column<int>(type: "int", nullable: true),
                    RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Department", x => x.DepartmentID);
                    table.ForeignKey(
                        name: "FK_Department_Teachers_TeacherID",
                        column: x => x.TeacherID,
                        principalTable: "Teachers",
                        principalColumn: "TeacherID");
                });

            migrationBuilder.CreateTable(
                name: "Courses",
                columns: table => new
                {
                    CourseID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Credits = table.Column<int>(type: "int", nullable: false),
                    DepartmentID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Courses", x => x.CourseID);
                    table.ForeignKey(
                        name: "FK_Courses_Department_DepartmentID",
                        column: x => x.DepartmentID,
                        principalTable: "Department",
                        principalColumn: "DepartmentID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "CourseTeacher",
                columns: table => new
                {
                    CoursesCourseID = table.Column<int>(type: "int", nullable: false),
                    TeachersTeacherID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CourseTeacher", x => new { x.CoursesCourseID, x.TeachersTeacherID });
                    table.ForeignKey(
                        name: "FK_CourseTeacher_Courses_CoursesCourseID",
                        column: x => x.CoursesCourseID,
                        principalTable: "Courses",
                        principalColumn: "CourseID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_CourseTeacher_Teachers_TeachersTeacherID",
                        column: x => x.TeachersTeacherID,
                        principalTable: "Teachers",
                        principalColumn: "TeacherID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Enrollments",
                columns: table => new
                {
                    EnrollmentID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CourseID = table.Column<int>(type: "int", nullable: false),
                    StudentID = table.Column<int>(type: "int", nullable: false),
                    Grade = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Enrollments", x => x.EnrollmentID);
                    table.ForeignKey(
                        name: "FK_Enrollments_Courses_CourseID",
                        column: x => x.CourseID,
                        principalTable: "Courses",
                        principalColumn: "CourseID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Enrollments_students_StudentID",
                        column: x => x.StudentID,
                        principalTable: "students",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Teachers",
                columns: new[] { "TeacherID", "FirstMidName", "HireDate", "LastName" },
                values: new object[,]
                {
                    { 1, "Ram", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Dev" },
                    { 2, "Laxmi", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Ranjan" },
                    { 3, "Ravi", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Krishnan" },
                    { 4, "Leena", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Rao" },
                    { 5, "Pandit", new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Narayan" }
                });

            migrationBuilder.InsertData(
                table: "students",
                columns: new[] { "ID", "Age", "EnrollmentDate", "FirstMidName", "Gender", "Grade", "LastName" },
                values: new object[,]
                {
                    { 100, 8, new DateTime(2023, 8, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Ravi", "Male", "Grade 3", "Kishan" },
                    { 101, 8, new DateTime(2023, 2, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Hana", "Female", "Grade 3", "Alonso" },
                    { 102, 8, new DateTime(2023, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Lisa", "Female", "Grade 3", "grey" },
                    { 103, 9, new DateTime(2023, 9, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Mustafa", "Male", "Grade 4", "Ali" },
                    { 104, 9, new DateTime(2023, 5, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Andrew", "Male", "Grade 4", "Li" },
                    { 105, 10, new DateTime(2023, 2, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "William", "Male", "Grade 5", "Justice" },
                    { 106, 10, new DateTime(2023, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Laura", "Female", "Grade 5", "Norman" },
                    { 107, 11, new DateTime(2023, 7, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), "Nino", "Male", "Grade 6", "Olivetto" }
                });

            migrationBuilder.InsertData(
                table: "Department",
                columns: new[] { "DepartmentID", "Budget", "Name", "StartDate", "TeacherID" },
                values: new object[] { 1, 100m, "Department1", new DateTime(2023, 7, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 1 });

            migrationBuilder.InsertData(
                table: "Courses",
                columns: new[] { "CourseID", "Credits", "DepartmentID", "Title" },
                values: new object[,]
                {
                    { 1050, 3, 1, "Chemistry" },
                    { 1051, 3, 1, "Microeconomics" },
                    { 1052, 3, 1, "Macroeconomics" },
                    { 1053, 4, 1, "Calculus" },
                    { 1054, 4, 1, "Trigonometry" },
                    { 1055, 3, 1, "Composition" },
                    { 1056, 4, 1, "Literature" }
                });

            migrationBuilder.InsertData(
                table: "Enrollments",
                columns: new[] { "EnrollmentID", "CourseID", "Grade", "StudentID" },
                values: new object[,]
                {
                    { 100, 1050, 0, 100 },
                    { 101, 1051, 2, 100 },
                    { 102, 1051, 1, 100 },
                    { 103, 1050, 1, 107 },
                    { 104, 1055, 4, 107 },
                    { 105, 1055, 4, 107 },
                    { 106, 1056, null, 106 },
                    { 107, 1056, null, 105 },
                    { 108, 1054, 4, 103 },
                    { 109, 1054, 2, 103 },
                    { 110, 1055, null, 104 },
                    { 111, 1052, 0, 104 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Courses_DepartmentID",
                table: "Courses",
                column: "DepartmentID");

            migrationBuilder.CreateIndex(
                name: "IX_CourseTeacher_TeachersTeacherID",
                table: "CourseTeacher",
                column: "TeachersTeacherID");

            migrationBuilder.CreateIndex(
                name: "IX_Department_TeacherID",
                table: "Department",
                column: "TeacherID");

            migrationBuilder.CreateIndex(
                name: "IX_Enrollments_CourseID",
                table: "Enrollments",
                column: "CourseID");

            migrationBuilder.CreateIndex(
                name: "IX_Enrollments_StudentID",
                table: "Enrollments",
                column: "StudentID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CourseTeacher");

            migrationBuilder.DropTable(
                name: "Enrollments");

            migrationBuilder.DropTable(
                name: "Courses");

            migrationBuilder.DropTable(
                name: "students");

            migrationBuilder.DropTable(
                name: "Department");

            migrationBuilder.DropTable(
                name: "Teachers");
        }
    }
}
