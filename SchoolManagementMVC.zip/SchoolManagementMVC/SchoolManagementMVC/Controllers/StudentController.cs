﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using SchoolManagementMVC.DAL;
using SchoolManagementMVC.Models;


namespace SchoolManagementMVC.Controllers
{
    [Authorize]
    public class StudentController : Controller
    {
        private readonly SchoolContext _context;
       
        public StudentController(SchoolContext context)
        {
            _context = context;
        }
        // GET: Student        
        /*public async Task<IActionResult> Index()
        {
            return _context.students != null ? 
                        View(await _context.students.ToListAsync()) :
                        Problem("Entity set 'SchoolContext.students'  is null.");

          */
            public ActionResult Index(string sortOrder, string searchString, int? page)
            {
                ViewBag.NameSortParm = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
                ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";
            ViewBag.numbersortParm = String.IsNullOrEmpty(sortOrder) ? "number_desc" : "";

            var students = from s in _context.students
                               select s;
            if (!String.IsNullOrEmpty(searchString))
            {
                students = students.Where(s => s.LastName.Contains(searchString)
                                       || s.FirstMidName.Contains(searchString) || s.Grade.Contains(searchString)
                                       || s.Gender.Contains(searchString)|| s.ID.Equals(searchString)
                                       ||s.Age.Equals(searchString));
            }
            switch (sortOrder)
               {
                    case "name_desc":
                        students = students.OrderByDescending(s => s.LastName);
                        students = students.OrderByDescending(s => s.FirstMidName);
                        students = students.OrderByDescending(s => s.Gender);
                        students = students.OrderByDescending(s => s.Grade);
                    break;
                case "number_desc":
                    students = students.OrderByDescending(s => s.Age);
                    students = students.OrderByDescending(s => s.ID);
                    break;
                case "Date":
                        students = students.OrderBy(s => s.EnrollmentDate);
                        break;
                    case "date_desc":
                        students = students.OrderByDescending(s => s.EnrollmentDate);
                        break;
                    default:
                        students = students.OrderBy(s => s.LastName);
                        break;
                }           
            return View(students.ToList());
            }        
        // GET: Student/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.students == null)
            {
                return NotFound();
            }
            _context.Enrollments.Include(u => u.Course.Title);
            var student = await _context.students.Include(u=>u.Enrollments).FirstOrDefaultAsync(m => m.ID == id);
            

            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }        
        // GET: Student/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Student/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("LastName,FirstMidName,Gender,Age,Grade,EnrollmentDate")] Student student)
        {
            if (ModelState.IsValid)
            {
                _context.Add(student);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(student);
        }

        // GET: Student/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.students == null)
            {
                return NotFound();
            }

            var student = await _context.students.FindAsync(id);
            if (student == null)
            {
                return NotFound();
            }
            return View(student);
        }

        // POST: Student/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,LastName,FirstMidName,Gender,Age,Grade,EnrollmentDate")] Student student)
        {
            if (id != student.ID)
            {
                return NotFound();
            }           
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(student);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StudentExists(student.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(student);
        }

        // GET: Student/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.students == null)
            {
                return NotFound();
            }

            var student = await _context.students
                .FirstOrDefaultAsync(m => m.ID == id);
            if (student == null)
            {
                return NotFound();
            }

            return View(student);
        }

        // POST: Student/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.students == null)
            {
                return Problem("Entity set 'SchoolContext.students'  is null.");
            }
            var student = await _context.students.FindAsync(id);
            if (student != null)
            {
                _context.students.Remove(student);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StudentExists(int id)
        {
          return (_context.students?.Any(e => e.ID == id)).GetValueOrDefault();
        }
    }
}
