﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementMVC.Models;
using System.Linq;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.Reflection.Metadata;

namespace SchoolManagementMVC.DAL
{
    public class SchoolContext: DbContext
    {
        public SchoolContext(DbContextOptions<SchoolContext> options) : base(options)
        {
        }        
        public DbSet<Student> students { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Teacher>Teachers  { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Student>()
       .HasMany(e => e.Enrollments)
       .WithOne(e => e.Student)
       .HasForeignKey(e => e.StudentID)
       .HasPrincipalKey(e => e.ID);

            modelBuilder.Entity<Student>().Property(e => e.ID).UseIdentityColumn();
            modelBuilder.Entity<Student>().HasData(new List<Student>
            {
                new Student{ID=100,FirstMidName="Ravi",LastName="Kishan",
                    EnrollmentDate=DateTime.Parse("2023-08-01"),Age=8,Grade="Grade 3",Gender="Male"
                },
                new Student{ID=101,FirstMidName="Hana",LastName="Alonso",EnrollmentDate=DateTime.Parse("2023-02-01"),
                Age=8,Grade="Grade 3",Gender="Female"
                },
                new Student{ID=102,FirstMidName="Lisa",LastName="grey",EnrollmentDate=DateTime.Parse("2023-01-01"),
                Age=8,Grade="Grade 3",Gender="Female"},
                new Student{ID=103,FirstMidName="Mustafa",LastName="Ali",EnrollmentDate=DateTime.Parse("2023-09-01"),
                Age=9,Grade="Grade 4",Gender="Male"},
                new Student{ID=104,FirstMidName="Andrew",LastName="Li",EnrollmentDate=DateTime.Parse("2023-05-01"),
                Age=9,Grade="Grade 4",Gender="Male"},
                new Student{ID=105,FirstMidName="William",LastName="Justice",EnrollmentDate=DateTime.Parse("2023-02-01"),
                Age=10,Grade="Grade 5",Gender="Male"},
                new Student{ID=106,FirstMidName="Laura",LastName="Norman",EnrollmentDate=DateTime.Parse("2023-03-01"),
                Age=10,Grade="Grade 5",Gender="Female"},
                new Student{ID=107,FirstMidName="Nino",LastName="Olivetto",EnrollmentDate=DateTime.Parse("2023-07-01"),
                Age=11,Grade="Grade 6",Gender="Male"}
            });
            modelBuilder.Entity<Course>().Property(e => e.CourseID).UseIdentityColumn();
            modelBuilder.Entity<Course>().HasData(new List<Course>
            {                
                new Course{CourseID=1050,Title="Chemistry",Credits=3,DepartmentID=1},
                new Course{CourseID=1051,Title="Microeconomics",Credits=3,DepartmentID=1},
                new Course{CourseID=1052,Title="Macroeconomics",Credits=3,DepartmentID=1},
                new Course{CourseID=1053,Title="Calculus",Credits=4,DepartmentID=1},
                new Course{CourseID=1054,Title="Trigonometry",Credits=4,DepartmentID=1 },
                new Course{CourseID=1055,Title="Composition",Credits=3,DepartmentID=1},
                new Course{CourseID=1056,Title="Literature",Credits=4,DepartmentID=1}
            });
            //courses.ForEach(s => context.Courses.Add(s));
            //context.SaveChanges();
            modelBuilder.Entity<Enrollment>().Property(e => e.EnrollmentID).UseIdentityColumn();
            modelBuilder.Entity<Enrollment>().HasData(new List<Enrollment>
            {
                new Enrollment{StudentID=100,CourseID=1050,Grade=Grade.A,EnrollmentID=100},
                new Enrollment{StudentID=100,CourseID=1051,Grade=Grade.C,EnrollmentID=101},
                new Enrollment{StudentID=100,CourseID=1051,Grade=Grade.B,EnrollmentID=102},
                new Enrollment{StudentID=107,CourseID=1050,Grade=Grade.B,EnrollmentID=103},
                new Enrollment{StudentID=107,CourseID=1055,Grade=Grade.F,EnrollmentID=104},
                new Enrollment{StudentID=107,CourseID=1055,Grade=Grade.F,EnrollmentID=105},
                new Enrollment{StudentID=106,CourseID=1056,EnrollmentID=106},
                new Enrollment{StudentID=105,CourseID=1056,EnrollmentID=107},
                new Enrollment{StudentID=103,CourseID=1054,Grade=Grade.F,EnrollmentID=108},
                new Enrollment{StudentID=103,CourseID=1054,Grade=Grade.C,EnrollmentID=109},
                new Enrollment{StudentID=104,CourseID=1055,EnrollmentID=110},
                new Enrollment{StudentID=104,CourseID=1052,Grade=Grade.A,EnrollmentID=111}
            });
            /*enrollments.ForEach(s => context.Enrollments.Add(s));
            context.SaveChanges();*/
            modelBuilder.Entity<Teacher>().Property(e => e.TeacherID).UseIdentityColumn();
            modelBuilder.Entity<Teacher>().HasData(new List<Teacher>
            {
                new Teacher{FirstMidName="Ram",LastName="Dev",TeacherID=1},
               new Teacher{FirstMidName="Laxmi",LastName="Ranjan",TeacherID=2},
               new Teacher{FirstMidName="Ravi",LastName="Krishnan",TeacherID=3},
               new Teacher{FirstMidName="Leena",LastName="Rao",TeacherID=4},
               new Teacher{FirstMidName="Pandit",LastName="Narayan",TeacherID=5}
            });
            modelBuilder.Entity<Department>().HasData(new List<Department>
            {
                new Department{DepartmentID=1,Budget=100,StartDate=DateTime.Parse("2023-07-01"), Name="Department1", TeacherID=1}            
            });
        }
        public DbSet<SchoolManagementMVC.Models.Department>? Department { get; set; }
    }
}
