﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SchoolManagementMVC.Models
{
    public class Student
    {
        public int ID { get; set; }
        [DisplayName("Last Name")]
        public string LastName { get; set; }

        [DisplayName("First Name")]
        public string FirstMidName { get; set; }

        [DisplayName("Gender")]
        public string Gender { get; set; }

        [DisplayName("Age")]
        public int Age { get; set; }
       
        [DisplayName("Grade")]
        public string Grade { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        [DisplayName("Enrollment Date")]
        public DateTime EnrollmentDate { get; set; }
        public virtual ICollection<Enrollment> Enrollments { get; set; }
        public enum gender
        {
            Male,Female
        }
    }
}
